---
name: Sophisticated Tech
colors:
  surface: '#fcf8fa'
  surface-dim: '#dcd9db'
  surface-bright: '#fcf8fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#f0edef'
  surface-container-high: '#ebe7e9'
  surface-container-highest: '#e5e1e4'
  on-surface: '#1c1b1d'
  on-surface-variant: '#46464d'
  inverse-surface: '#313032'
  inverse-on-surface: '#f3f0f2'
  outline: '#77767d'
  outline-variant: '#c7c5cd'
  surface-tint: '#5a5d76'
  primary: '#5a5d76'
  on-primary: '#ffffff'
  primary-container: '#bfc1de'
  on-primary-container: '#4c4f67'
  inverse-primary: '#c2c4e2'
  secondary: '#5c5f61'
  on-secondary: '#ffffff'
  secondary-container: '#e1e3e5'
  on-secondary-container: '#626567'
  tertiary: '#635f3d'
  on-tertiary: '#ffffff'
  tertiary-container: '#cac49b'
  on-tertiary-container: '#555130'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe0fe'
  primary-fixed-dim: '#c2c4e2'
  on-primary-fixed: '#171a30'
  on-primary-fixed-variant: '#42455d'
  secondary-fixed: '#e1e3e5'
  secondary-fixed-dim: '#c5c7c9'
  on-secondary-fixed: '#191c1e'
  on-secondary-fixed-variant: '#444749'
  tertiary-fixed: '#eae4b8'
  tertiary-fixed-dim: '#cec89e'
  on-tertiary-fixed: '#1f1c03'
  on-tertiary-fixed-variant: '#4b4828'
  background: '#fcf8fa'
  on-background: '#1c1b1d'
  surface-variant: '#e5e1e4'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style

The design system is engineered to convey the personality of a premium, multi-faceted commerce ecosystem. It balances the authority of a financial institution with the approachability of a high-end lifestyle brand. The target audience includes tech-savvy consumers, professional vendors, and specialized technicians who value efficiency and security.

The visual style is **Corporate Modern with a Minimalist lean**. It utilizes ample negative space to reduce cognitive load across the four complex marketplaces. Key characteristics include:
- **Depth and Layering:** Drawing from high-end tech aesthetics, the system uses soft depth to separate the four ecosystem pillars (New, Used, Services, Auctions).
- **Trust-First Interface:** Bold, legible typography and a stable color palette reinforce platform reliability.
- **Dynamic Overlays:** Inspired by the hero elements in the reference imagery, the system utilizes "floating" product photography that breaks standard grid containers to create a sense of movement and premium quality.

## Colors

The color strategy is anchored in a deep "Trust Navy" (`#0F172A`) for foundational elements, while introducing a sophisticated "Soft Periwinkle" (`#BFC1DE`) as the primary accent. Interaction is supported by a sophisticated "Steel Silver" (`#BFC1C3`) to ensure critical touchpoints—like bidding or booking—are unmistakable yet professional, complemented by a "Deep Moss" (`#373416`) tertiary tone for high-value segments.

- **Primary (Soft Periwinkle):** A refined, light violet-blue used for primary action surfaces, highlighting active states, and creating a soft, tech-forward energy.
- **Secondary (Steel Silver):** Reserved for secondary actions and active states where a more neutral, sophisticated touch is required compared to high-vibrancy alternatives.
- **Tertiary (Deep Moss):** A dark, earthy olive-tone used for specialized status indicators, high-end auction labels, or secondary accents that require a grounded, premium feel distinct from the blues and grays.
- **Surface Strategy:** We use a tiered gray system derived from the navy seed. `#FFFFFF` is used for primary content cards, while the background shifts to a very subtle cool tint to define the "Discovery Hub" zones.
- **Ecosystem Accents:** Subtle color coding distinguishes the marketplaces (e.g., Deep Moss for high-value Auctions, Purple for Repairs) used sparingly in labels or status indicators.

## Typography

This design system utilizes **Inter** exclusively to maintain a clean, systematic feel. The hierarchy is defined by generous tracking in headings and tight, functional spacing for labels.

- **Hero Typography:** Uses tight letter-spacing (`-0.04em`) to create a compact, high-fashion editorial look for the main marketplace entries.
- **Readability:** Body text is set with a generous `1.6` line height to ensure clarity during long technical repair descriptions or auction terms.
- **Information Density:** Labels use a medium weight (`500`) to stand out against white surfaces without requiring the visual weight of bold text.

## Layout & Spacing

The layout employs a **12-column fixed grid** for desktop, centered within the viewport. To achieve the "premium" feel requested, the system uses exaggerated vertical spacing (`section-gap`) between the different marketplace modules.

- **The Discovery Hub:** The homepage utilizes a "category-driven" navigation strip inspired by the reference images, using circular avatars for quick mental mapping of product types.
- **Overlapping Elements:** Hero sections allow for 15% overflow of product imagery outside their containers, creating a layered, 3D effect.
- **Responsive Behavior:** On tablet, the grid collapses to 8 columns with reduced gutters. On mobile, it shifts to a single-column fluid layout with 20px side margins.

## Elevation & Depth

Visual hierarchy is established through **Ambient Shadows** and **Tonal Layering**. We avoid harsh borders in favor of soft, diffused shadows that suggest the UI elements are resting on a bed of air.

- **Level 1 (Base):** The foundation background derived from the seed color.
- **Level 2 (Cards):** White surfaces with a very soft `0px 4px 20px rgba(15, 23, 42, 0.05)` shadow. This is the standard for product listings and service requests.
- **Level 3 (Interactive):** Elements like "Place Bid" or "Buy Now" cards use a more pronounced `0px 12px 30px rgba(15, 23, 42, 0.1)` shadow on hover to invite interaction.
- **Glassmorphism:** Navigation headers use a subtle backdrop blur (12px) with 80% opacity white to maintain context as the user scrolls through the vast ecosystem.

## Shapes

The design system embraces a **Rounded** philosophy to soften the "Tech" aesthetic and make the platform feel more approachable and trustworthy.

- **Standard Components:** Buttons and input fields use a `0.5rem` (rounded) base.
- **Container Elements:** Product cards and marketplace category sections use `1.5rem` (rounded-xl) or `2rem` (rounded-2xl) to create the friendly, soft-edged look seen in the references.
- **Category Icons:** Always use a perfect circle (pill-shaped) for high-level navigation to distinguish "Types of Commerce" from "Product Cards."

## Components

### Buttons
- **Primary:** Soft Periwinkle (`#BFC1DE`) background, dark text, 2xl roundedness. Subtle scale-up transform (1.02x) on hover.
- **Action (Accent):** Used specifically for the "Success" path—Confirming a repair, Winning an auction, or Completing a purchase.
- **Secondary:** Steel Silver background with dark text for lower-priority navigation and secondary UI actions.

### Cards
- **Product Card:** Clean white background, no visible border, soft ambient shadow. Product image is centered with a subtle "inner-glow" to separate it from the card surface.
- **Auction Card:** Includes a persistent "Time Remaining" badge in the top right using the **Deep Moss** (`#373416`) tertiary color for high-contrast visibility on time-sensitive auctions.

### Input Fields
- High-quality, minimal inputs with `1px` light gray borders that turn `Steel Silver` on focus. Large padding (16px) for a "premium" tactile feel.

### Marketplace Switcher
- A persistent, high-level navigation component that allows users to toggle between "New," "Used," "Repairs," and "Auctions," using soft-pill shapes and icon + label combinations.

### Reputation Badges
- Small, high-contrast chips that appear next to vendor and technician names, utilizing a star icon and a numerical score, ensuring trust is visible at every touchpoint.